package com.example.receipe_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
